from .main import app  # or whatever file your Typer app is in
app()